import os
import boto3
from boto3.dynamodb.conditions import Key

from data import classroom_attendance_entries, class_roster_entries

# Set the environment variables for the credentials and config files
os.environ['AWS_SHARED_CREDENTIALS_FILE'] = ".aws/credentials"
os.environ['AWS_CONFIG_FILE'] = ".aws/config"

dynamodb = boto3.resource("dynamodb")
classroom_attendance_table = dynamodb.Table("ClassroomAttendance")
classroom_roster_table = dynamodb.Table("ClassroomRoster")

# Functionality 1: Get Attendance Percentage for Student
def get_all_attendance_by_class():
    # Scan the table and get all the items
    items = classroom_attendance_table.scan()['Items']

    # Organize attendance entries by class
    attendance_by_class = {}
    for item in items:
        class_id = item['ClassID']
        if class_id not in attendance_by_class:
            attendance_by_class[class_id] = []
        attendance_by_class[class_id].append(item)

    return attendance_by_class

# Functionality 2: Add Attendance Entry
def add_attendance_entry(class_id, date, student_id, student_name, attendance_status):
    classroom_attendance_table.put_item(
        Item={
            "ClassID": class_id,
            "Date": date,
            "StudentID": student_id,
            "Name": student_name,
            "Attendance Status": attendance_status
        }
    )

# Functionality 3: Update Attendance Entry
def update_attendance_entry(class_id, date, student_id, updated_status):
    classroom_attendance_table.update_item(
        Key={
            "ClassID": class_id,
            "Date": date
        },
        UpdateExpression="set StudentID=:s, AttendanceStatus=:a",
        ExpressionAttributeValues={
            ":s": student_id,
            ":a": updated_status
        }
    )

# Functionality 4: Delete Attendance Entry
def delete_attendance_entry(class_id, date, student_id):
    response = classroom_attendance_table.delete_item(
        Key={
            "ClassID": class_id,
            "Date": date
        }
    )

# Functionality 5: Get Class Attendance for a Specific Date
def get_class_attendance(class_id, date):
    response = classroom_attendance_table.query(
        KeyConditionExpression=Key("ClassID").eq(class_id) & Key("Date").eq(date)
    )
    return response["Items"]

# Functionality 6: Get Student Attendance for a Specific Date Range
def get_student_attendance(student_id, start_date, end_date):
    response = classroom_attendance_table.query(
        IndexName="StudentID-Date-index",
        KeyConditionExpression=Key("StudentID").eq(student_id) & Key("Date").between(start_date, end_date)
    )
    return response["Items"]

# Functionality 7: Add Student to Class
def add_student_to_class(class_id, student_id, student_name):
    classroom_roster_table.put_item(
        Item={
            "ClassID": class_id,
            "StudentID": student_id,
            "StudentName": student_name
        }
    )

# Functionality 8: Remove Student from Class
def remove_student_from_class(class_id, student_id):
    classroom_roster_table.delete_item(
        Key={
            "ClassID": class_id,
            "StudentID": student_id
        }
    )

# Functionality 9: Get Class Roster
def get_class_roster(class_id):
    response = classroom_roster_table.query(
        KeyConditionExpression=Key("ClassID").eq(class_id)
    )
    return response["Items"]

# Functionality 10: Get Attendance Summary for Class
def get_attendance_summary(class_id, start_date, end_date):
    response = classroom_attendance_table.query(
        KeyConditionExpression=Key("ClassID").eq(class_id) & Key("Date").between(start_date, end_date)
    )
    summary = {}
    for item in response["Items"]:
        status = item["Attendance Status"]
        student_id = item["StudentID"]
        if student_id not in summary:
            summary[student_id] = {"Present": 0, "Absent": 0, "Late": 0}
        summary[student_id][status] += 1
    return summary

# Functionality 11: Get Attendance Percentage for Student
def get_attendance_percentage(student_id, class_id, start_date, end_date):
    response = classroom_attendance_table.query(
        IndexName="StudentID-Date-index",
        KeyConditionExpression=Key("StudentID").eq(student_id) & Key("Date").between(start_date, end_date)
    )
    present_count = sum(1 for item in response["Items"] if item["Attendance Status"] == "Present")
    total_count = len(response["Items"])
    return (present_count / total_count) * 100 if total_count > 0 else 0

def main():
    while True:
        print("\nClassroom Attendance Management Application")
        print("Select an option:")
        print("1. Get all attendance by class")
        print("2. Add attendance entry")
        print("3. Update attendance entry")
        print("4. Delete attendance entry")
        print("5. Get class attendance for a specific date")
        print("6. Get student attendance for a specific date range")
        print("7. Add student to class")
        print("8. Remove student from class")
        print("9. Get class roster")
        print("10. Get attendance summary for class")
        print("11. Get attendance percentage for student")
        print("q. Quit")
        
        choice = input("Enter the number of your choice (or \"q\" to quit): ").strip()
        
        if choice == "q":
            break

        elif choice == "1":
            attendance_by_class = get_all_attendance_by_class()
            for class_id, class_attendances in attendance_by_class.items():
                print(f'Class ID: {class_id}')
                for class_attendance in class_attendances:
                    print(f'    Date: {class_attendance["Date"]}')
                    print(f'        StudentID: {class_attendance["StudentID"]}')
                    print(f'        Name: {class_attendance["Name"]}')
                    print(f'        Attendance Status: {class_attendance["Attendance Status"]}', "\n")

        elif choice == "2":
            class_id = input("Enter the Class ID: ").strip()
            date = input("Enter the Date (YYYY-MM-DD): ").strip()
            student_id = input("Enter the Student ID: ").strip()
            student_name = input("Enter the Student Name: ").strip()
            attendance_status = input("Enter the Attendance Status (Present/Absent/Late): ").strip()
            add_attendance_entry(class_id, date, student_id, student_name, attendance_status)
            print("Attendance entry added successfully.")

        elif choice == "3":
            class_id = input("Enter the Class ID: ").strip()
            date = input("Enter the Date (YYYY-MM-DD): ").strip()
            student_id = input("Enter the Student ID: ").strip()
            updated_status = input("Enter the Updated Attendance Status (Present/Absent/Late): ").strip()
            update_attendance_entry(class_id, date, student_id, updated_status)
            print("Attendance entry updated successfully.")

        elif choice == "4":
            class_id = input("Enter the Class ID: ").strip()
            date = input("Enter the Date (YYYY-MM-DD): ").strip()
            student_id = input("Enter the Student ID: ").strip()
            delete_attendance_entry(class_id, date, student_id)
            print("Attendance entry deleted successfully.")

        elif choice == "5":
            class_id = input("Enter the Class ID: ").strip()
            date = input("Enter the Date (YYYY-MM-DD): ").strip()
            attendance = get_class_attendance(class_id, date)
            print(f'Class Attendance for Class ID {class_id} on {date}:')
            for record in attendance:
                print(f'{record["StudentID"]}: {record["Name"]} - {record["Attendance Status"]}')

        elif choice == "6":
            student_id = input("Enter the Student ID: ").strip()
            start_date = input("Enter the Start Date (YYYY-MM-DD): ").strip()
            end_date = input("Enter the End Date (YYYY-MM-DD): ").strip()
            attendance = get_student_attendance(student_id, start_date, end_date)
            print(f'Attendance for Student ID {student_id} between {start_date} and {end_date}:')
            for record in attendance:
                print(f'{record["Date"]}: {record["Attendance Status"]}')

        elif choice == "7":
            class_id = input("Enter the Class ID: ").strip()
            student_id = input("Enter the Student ID: ").strip()
            student_name = input("Enter the Student Name: ").strip()
            add_student_to_class(class_id, student_id, student_name)
            print("Student added to the class successfully.")

        elif choice == "8":
            class_id = input("Enter the Class ID: ").strip()
            student_id = input("Enter the Student ID: ").strip()
            remove_student_from_class(class_id, student_id)
            print("Student removed from the class successfully.")

        elif choice == "9":
            class_id = input("Enter the Class ID: ").strip()
            roster = get_class_roster(class_id)
            print(f'Class Roster for Class ID {class_id}:')
            for student in roster:
                print(f'{student["StudentID"]}: {student["Name"]}')

        elif choice == "10":
            class_id = input("Enter the Class ID: ").strip()
            start_date = input("Enter the Start Date (YYYY-MM-DD): ").strip()
            end_date = input("Enter the End Date (YYYY-MM-DD): ").strip()
            summary = get_attendance_summary(class_id, start_date, end_date)
            print(f'Attendance Summary for Class ID {class_id} between {start_date} and {end_date}:')
            for student_id, records in summary.items():
                print(f'Student ID {student_id}: Present - {records["Present"]}, Absent - {records["Absent"]}, Late - {records["Late"]}')

        elif choice == "11":
            student_id = input("Enter the Student ID: ").strip()
            class_id = input("Enter the Class ID: ").strip()
            start_date = input("Enter the Start Date (YYYY-MM-DD): ").strip()
            end_date = input("Enter the End Date (YYYY-MM-DD): ").strip()
            percentage = get_attendance_percentage(student_id, class_id, start_date, end_date)
            print(f'Attendance Percentage for Student ID {student_id} in Class ID {class_id} between {start_date} and {end_date}: {percentage:.2f}%')

        else:
            print("Invalid choice. Please try again.")

def clear_existing_table():
    # Scan the table and get all the items
    items = classroom_attendance_table.scan()["Items"]

    # Get the primary key attribute names from the table key schema
    primary_key_attribute_names = [key_schema['AttributeName'] for key_schema in classroom_attendance_table.key_schema]

    # Iterate through the items and delete each item using its primary key
    for item in items:
        primary_key = {attribute_name: item[attribute_name] for attribute_name in primary_key_attribute_names}
        classroom_attendance_table.delete_item(Key=primary_key)

    # Scan the table and get all the items
    items = classroom_roster_table.scan()["Items"]

    # Get the primary key attribute names from the table key schema
    primary_key_attribute_names = [key_schema['AttributeName'] for key_schema in classroom_roster_table.key_schema]

    # Iterate through the items and delete each item using its primary key
    for item in items:
        primary_key = {attribute_name: item[attribute_name] for attribute_name in primary_key_attribute_names}
        classroom_roster_table.delete_item(Key=primary_key)


def populate():
    for classroom_attendance_entry in classroom_attendance_entries:
        classroom_attendance_table.put_item(
            Item=classroom_attendance_entry
        )

    for class_roster_entry in class_roster_entries:
        classroom_roster_table.put_item(
            Item=class_roster_entry
        )


if __name__ == "__main__":
    clear_existing_table()
    populate()
    main()
